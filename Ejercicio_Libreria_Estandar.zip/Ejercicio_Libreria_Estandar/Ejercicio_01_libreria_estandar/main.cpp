#include <iostream>
#include <vector>
#include <random>
using namespace std;
template <typename Iterator , typename  Objeto>
Iterator find( Iterator start, Iterator end,  const Objeto& x)
{

    for (auto it = start; it != end; advance(it, 1))
    {
        //cout<<*it << " ";
        if (*it == x)
        {
            //cout << endl;
            //cout << *it << " ";
            return it;
        }
    }
}

int main() {

    vector<int> v1 = {1,2,3,4,5,100,20,5};

    auto start = v1.begin();
    auto end = v1.end();

     find(start,end,5);

    return 0;
}