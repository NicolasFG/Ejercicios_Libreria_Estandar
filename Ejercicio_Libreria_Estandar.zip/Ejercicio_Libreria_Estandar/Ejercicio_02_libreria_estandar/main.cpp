#include <iostream>
#include <list>
using namespace std;


template <typename InputIt1, typename InputIt2, typename OutputIt>

OutputIt merge (InputIt1 first1, InputIt1 last1, InputIt2 first2, InputIt2 last2, OutputIt d_first)
{
    list<int> temp;
    for(;first1 != last1 ; first1++)
    {
        temp.push_back(*first1);
    }

    for(;first2 != last2 ; first2++)
    {
        temp.push_back(*first2);
    }
temp.sort();

    d_first = temp.begin();

    for(;d_first != temp.end(); d_first++)
    {
        cout<<*d_first;
    }
    return d_first;
}

int main() {

    list<int> lista1 = {1,2,3,4};
    list<int> lista2 = {5,6,7,8};
    list<int> lista3;

    merge(lista1.begin(),lista1.end(),lista2.begin(),lista2.end(),lista3.begin());



    return 0;
}