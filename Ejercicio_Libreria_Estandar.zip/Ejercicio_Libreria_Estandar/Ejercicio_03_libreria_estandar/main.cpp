#include <iostream>
#include <list>
using namespace std;

template <typename L1, typename L2>
void intersec(L1 lista1, L2 lista2)
{
    list<int> temp;

    auto it1 = lista1.begin();
    auto it2 = lista2.begin();

    for (; it1 != lista1.end(); it1++)
    {
        for(; it2 != lista2.end(); it2++)
        {
            if(*it1 == *it2)
            {
                temp.push_back(*it1);
            }

        }
        it2 = lista2.begin();
    }

    auto it3 = temp.begin();

    for(;it3 != temp.end();it3++)
    {
        cout << *it3;
    }
}


int main() {
    list <int> lista1 = {1,2,3,4,5};
    list <int> lista2 = {2,3,6,7,8};

    intersec(lista1,lista2);

    return 0;
}