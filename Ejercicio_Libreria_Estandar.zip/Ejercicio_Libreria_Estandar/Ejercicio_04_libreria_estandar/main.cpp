#include <iostream>
#include <list>
using namespace std;
template<typename L1, typename L2>
auto unio(L1 list1, L2 list2){
    list<int> temp;
    auto it1 = list1.begin();
    auto it2= list2.begin();

    list1.sort();
    list2.sort();

    list1.unique();
    list2.unique();

    for(;it1 != list1.end(); it1++)
    {
        temp.push_back(*it1);
    }
    for(;it2 != list2.end(); it2++)
    {
        temp.push_back(*it2);
    }

    temp.sort();
    temp.unique();

    auto it3 = temp.begin();
    for(;it3 != temp.end(); it3++)
    {
        cout<< *it3 << " ";
    }

}

int main() {

    list<int> lista1 = {1,1,2,2};
    list<int> lista2 = {3,3,1,1};
    unio(lista1,lista2);

    return 0;
}