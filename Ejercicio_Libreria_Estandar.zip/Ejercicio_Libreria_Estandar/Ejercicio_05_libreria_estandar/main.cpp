#include <iostream>
#include <vector>
#include <list>

using namespace std;

//Implementacion para list
template <typename T, typename Contenedor>
void insert_sorted (Contenedor c, T valor){
    c.sort();
    auto it1 = c.begin();
    c.push_back(valor);
    for(auto it2 = c.begin(); it2 != c.end(); it2++)
    {
        cout<<*it2<<" ";
    }
}


int main() {

    list<int> v1 = {1,4,5,2,3,100,40,6};
    insert_sorted(v1,1000);

    return 0;
}