#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;



template <typename ForwardIt, typename T>
ForwardIt remov(ForwardIt first, ForwardIt last, const T& valor)
{
    vector<int> temp;
    for(;first != last; first++)
    {
        temp.push_back(*first);
    }
    auto last1 = remove_if(begin(temp), end(temp),[valor](T valor1){return valor1 == valor;});

    temp.erase(last1,end(temp));

    for(int & it3 : temp)
    {
        cout<<it3<<" ";
    }

    return last;
}

int main() {

vector<int> v1 = {1,2,3,4,5,6};

auto start = v1.begin();
auto end = v1.end();

remov(start,end,2);


    return 0;
}