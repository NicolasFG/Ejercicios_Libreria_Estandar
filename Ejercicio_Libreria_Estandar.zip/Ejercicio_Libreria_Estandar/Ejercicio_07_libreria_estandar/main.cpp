#include <iostream>
#include <vector>
using namespace std;
template <typename InputIt, typename OutputIt, typename c>
OutputIt cop(InputIt first, InputIt last, OutputIt d_first, c cd)
{
    vector<int> temp;

    for(;first != last;first++)
    {
        temp.push_back(*first);
    }

    auto it = cd.begin();
    for(;it != cd.end();it++)
    {
        temp.push_back(*it);
    }

    for(int i : temp)
        cout << i << " ";

    return last;
}

int main() {

vector<int> v1 = {1,2,3,4};
vector<int> v2 = {5,6,7,8};
auto it1 = v1.begin();
auto it2 = v1.end();

auto it3 = v2.begin();

cop(it1,it2,it3,v2);


    return 0;
}