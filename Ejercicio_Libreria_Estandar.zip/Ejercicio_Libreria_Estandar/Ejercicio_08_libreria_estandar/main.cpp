#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

template <class InputIt>
void for_each(InputIt first, InputIt last) {
    vector<int> temp;
    struct Sum {
        Sum() { sum = 0; }
        void operator()(int n) { sum += n; }
        int sum;
    };

    for_each(first, last, [](int &n) { return n; });
    Sum s = for_each(first, last, Sum());

    for (; first != last; first++) {
        temp.push_back(*first);
    }

    cout << "after:  ";
    for (auto i : temp) {
        cout << i << " ";
    }
    cout << '\n';
    cout << "sum: " << s.sum << '\n';


}

int main() {
    vector<int> nums{1,2};
    for_each(nums.begin(),nums.end());
    return 0;
}