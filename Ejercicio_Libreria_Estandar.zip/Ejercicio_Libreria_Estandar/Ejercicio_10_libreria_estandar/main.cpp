#include <iostream>
using namespace std;

int main() {
    int k;//variable para la velocidad a la que mueren las personas
    int n;//el numero de personas
    int gente[100];//arrreglo para la cantidad maxima de personas que tolera el programa
    int die=0, cont=0;//contadores
    int wisin = 0;//el sobreviviente

    cout << "Introduce el numero de personas: ";
    cin >> n;
    cout << "Introduce el intervalo en que mataras : ";
    cin >> k;

    for(int c=0; c<n; c++)
    {
        gente[c] = (c+1);
    }

    cout << "Los Romanos murieron el el orden siguiente: ";

    while(die != (n-1)) {

        for(int c1=0; c1<n; c1++) {

            if(gente[c1]!= 0)  {
                cont += 1;
                if(cont == k ){
                    cont = 0;
                    cout << gente[c1] << " ";
                    gente[c1] = 0;
                    die += 1;
                }
            }
        }
    }
    for(int c2=0; c2<n; c2++) {
        if(gente[c2] != 0) {
            wisin = gente[c2];
        }
    }
    cout<< endl;
    cout <<"wisin (El sobreviviente) es el numero: " << wisin;

    return 0;
}